import CancelIcon from '@mui/icons-material/Cancel';
import './ErrorMessage.scss'
interface ErrorProps {
    message: string;
    onClose: () => void;
  }
  interface ErrorMessageProps {
    error: ErrorProps;
  }
  const ErrorMessage = ({ error }: ErrorMessageProps) => {
  return (
    <div className="errorMessage" >
      {error.message}
      <CancelIcon className='closeButton' onClick={error.onClose}/>
    </div>
  )
}

export default ErrorMessage