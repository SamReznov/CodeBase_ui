import './EcpSfmcConnectionEntity.scss'
import { EcpSfmcConnection } from '../../dataInterfaces/SMFCConnectionInterfaces/SMFCConnectionInterface';

const EcpSfmcConnectionEntity = ({ data }: { data: EcpSfmcConnection }) => (
    <div className="viewer">
        <h2 className="viewer-title">EcpSfmcConnection</h2>
        <div className="viewer-field">
            <span className="viewer-field-name">Client ID:</span>
            <span className="viewer-field-value">{data.clientId}</span>
        </div>
        <div className="viewer-field">
            <span className="viewer-field-name">Client Secret:</span>
            <span className="viewer-field-value">{data.clientSecret}</span>
        </div>
        <div className="viewer-field">
            <span className="viewer-field-name">Distributor:</span>
            <span className="viewer-field-value">{data.distributor}</span>
        </div>
        <div className="viewer-field">
            <span className="viewer-field-name">SFMC URL:</span>
            <span className="viewer-field-value">{data.sfmcUrl}</span>
        </div>
    </div>
);

export default EcpSfmcConnectionEntity;