import intactImage from '../../images/intact.jpg'
import NavigationBar from '../../components/NavigationBar'
import './AppHeader.scss'
import { useNavigate } from 'react-router-dom'
import 'bootstrap/dist/css/bootstrap.css';
const AppHeader = () => {
    const navigate = useNavigate();

  return (
      <header>
      <section className="app-header">
        <section className="app-title-left">
          <img src={intactImage} alt="intact"  height={30} width={50}/>                    
        </section>

        <section className="app-title-center" style={{cursor:'pointer'}} onClick={()=>{navigate('/')}}><h4>SMFC</h4> </section>
        <section className="element-style-right">
       
        </section>
      </section>
      <div className="sub-header">
         <NavigationBar/>
      </div>
    </header>
  )
}

export default AppHeader