import React from 'react';
import './AppFooter.scss';

function AppFooter() {
  return (
    <div className="wrap-footer">
      <footer className="app-footer">
        &copy; INTACT
      </footer>
    </div>
  );
}

export default AppFooter;
