export interface EcpSfmcConnection {
    clientId: string;
    clientSecret: string;
    distributor: string;
    sfmcUrl: string;
  }