import { EcpSfmcConnection } from "../SMFCConnectionInterfaces/SMFCConnectionInterface";
import { EcpSfmcEventDefination } from "../SMFCEventDefinationInterfaces/SmFcEventDefinationInterface";
import { EcpSfmcMapping } from "../SMFCMappingListInterFaces/SMFCMappingListInterface";

export interface FormDataPayLoadForViewConfig {
    trackingNumber: string;
    code: string;
    distributor: string;
    province: string;
    underwritingCompany: string;
  }

  export interface ApiResponseFromSMFC {
    status: string;
    message: Message;
    errors: any;
  }

  
  export interface Message {
    trackingNumber: string;
    responseCode: string;
    value: {
      ecpSfmcConnection: EcpSfmcConnection;
      ecpSfmcEventDefination: EcpSfmcEventDefination;
      ecpSfmcMappingList: EcpSfmcMapping[];
    };
    timeStamp: string;
  }
  
