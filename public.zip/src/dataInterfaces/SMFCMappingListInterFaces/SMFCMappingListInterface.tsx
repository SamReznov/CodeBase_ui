export interface EcpSfmcMapping {
    digitalKey: string;
    ecpSfmcEventDefinationId: string;
    jsonSchema: string;
    salesforceKey: string;
    type: string;
  }