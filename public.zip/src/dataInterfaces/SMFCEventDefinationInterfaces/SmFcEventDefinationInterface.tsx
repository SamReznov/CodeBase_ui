export  interface EcpSfmcEventDefination {
    code: string;
    distributor: string;
    eventDefinationKey: string;
    province: string;
    sendType: string;
    underWritingCompany: string;
  }
  