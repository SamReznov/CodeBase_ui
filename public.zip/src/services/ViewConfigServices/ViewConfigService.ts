import axios, { AxiosResponse } from "axios";
import { ApiResponseFromSMFC, FormDataPayLoadForViewConfig } from "../../dataInterfaces/ViewConfigInterfaces/ViewConfigInterface";

const API_URL_FOR_VIEW_CONFIGURATION = "http://localhost:8080/json";
const HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
};

class ViewConfigService {
  getViewConfig(formData: FormDataPayLoadForViewConfig): Promise<AxiosResponse<ApiResponseFromSMFC>> {
    return axios.post<ApiResponseFromSMFC>(API_URL_FOR_VIEW_CONFIGURATION, formData, { headers: HEADERS });
  }
}
export default new ViewConfigService();
