import React from "react";
import logo from "./logo.svg";
import "./App.scss";
import NavigationBar from "./components/NavigationBar";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import EcpSfmcEventDefinationPage from "./pages/EcpSfmcEventDefination/EcpSfmcEventDefinationPage";
import EcpSfmcConnectionPage from "./pages/EcpSfmcConnection/EcpSfmcConnectionPage";
import EcpSfmcMappingListPage from "./pages/EcpSfmcMappingList/EcpSfmcMappingListPage";
import ViewConfigPage from "./pages/ViewConfig/ViewConfigPage";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />}>
          <Route path="/sfmcConnection" element={<EcpSfmcConnectionPage />} />
          <Route path="/sfmcEventDefination" element={<EcpSfmcEventDefinationPage />} />
          <Route path="/sfmcMappingList" element={<EcpSfmcMappingListPage />} />
          <Route index element={<ViewConfigPage/>} />
        </Route>

      </Routes>
    </BrowserRouter>
  );
}

export default App;
