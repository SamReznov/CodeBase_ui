// validate.ts
interface Errors {
    [key: string]: string;
}

interface FormData {
    [key: string]: string;
}

export const validateViewConfigForm = (name: string, value: string, formData: FormData): Errors => {
    let errors: Errors = {};

    // Add your validation logic here
    if (name === 'underwritingCompany' && value.trim() === '') {
        errors[name] = 'Underwriting company is required';
    }

    // ...add more validations for other fields...

    return errors;
};