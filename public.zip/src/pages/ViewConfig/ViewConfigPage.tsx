import React, { FormEvent, useState } from "react";
import { useOutletContext } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "react18-json-view/src/style.css";
import "./ViewConfigPage.scss";
import ViewConfigService from "../../services/ViewConfigServices/ViewConfigService";
import {
  ApiResponseFromSMFC,
  FormDataPayLoadForViewConfig,
} from "../../dataInterfaces/ViewConfigInterfaces/ViewConfigInterface";
import ErrorMessage from "../../components/ErrorMessage";
import JsonView from "react18-json-view";


const ViewConfigPage = () => {
  const [selectedOutlet, setSelectedOutlet] = useOutletContext<any>();
  const [fetchStatus, setFetchStatus] = useState<
    "idle" | "loading" | "succeeded" | "failed"
  >("idle");
  const [responseFromViewConfigApi, setResponseFromViewConfigApi] = useState<ApiResponseFromSMFC>(); // [1
  const [formData, setFormData] = useState<FormDataPayLoadForViewConfig>({
    trackingNumber: "",
    code: "",
    distributor: "",
    province: "",
    underwritingCompany: "",
  });

  const handleChange = (e: { target: { name: string; value: string } }) => {
    setFormData((prevState) => ({
      ...prevState,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      setFetchStatus("loading");
      const response = await ViewConfigService.getViewConfig(formData);
      console.log("response from view config api");
      console.log(response.data);
      setResponseFromViewConfigApi(response.data);
      setFetchStatus((prevState) => "succeeded");
    } catch (error) {
      console.log(error);
      setFetchStatus((prevState) => "failed");
    }
  };

  const handleReset = () => {
    setFormData((prevState) => ({
      trackingNumber: "",
      code: "",
      distributor: "",
      province: "",
      underwritingCompany: "",
    }));
  }
  
  const handleClose = () => {
    setFetchStatus((prevState) => "idle");
    
    console.log("close called");
  };




  

  return (
    <div className="container">
      <form onSubmit={handleSubmit} className="col-md-6 offset-md-3 form-box">
        <div className="row">
          <div className="col-md-4 mb-3">
            <label className="form-label">Tracking Number:</label>
            <input
              type="text"
              className="form-control"
              name="trackingNumber"
              value={formData.trackingNumber}
              onChange={handleChange}
            />
          </div>
          <div className="col-md-4 mb-3">
            <label className="form-label">Code:</label>
            <input
              type="text"
              className="form-control"
              name="code"
              value={formData.code}
              onChange={handleChange}
            />
          </div>
          <div className="col-md-4 mb-3">
            <label className="form-label">Distributor:</label>
            <input
              type="text"
              className="form-control"
              name="distributor"
              value={formData.distributor}
              onChange={handleChange}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-md-6 mb-3">
            <label className="form-label">Province:</label>
            <input
              type="text"
              className="form-control"
              name="province"
              value={formData.province}
              onChange={handleChange}
            />
          </div>
          <div className="col-md-6 mb-3">
            <label className="form-label">Underwriting Company:</label>
            <input
              type="text"
              className="form-control"
              name="underwritingCompany"
              value={formData.underwritingCompany}
              onChange={handleChange}
            />
          </div>
        </div>
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
        <button type="reset" className="btn btn-secondary" onClick={handleReset}>
          Reset
        </button>
      </form>

      {fetchStatus === "loading" && <div>Loading...</div>}
      {fetchStatus === "succeeded" && (
        <JsonView src={responseFromViewConfigApi} />
      )}
      {fetchStatus === "failed" && (
        <ErrorMessage
          error={{
            message: "Some Error Happened During Fetching the data",
            onClose: handleClose,
          }}
        />
      )}
    </div>
  );
};

export default ViewConfigPage;
