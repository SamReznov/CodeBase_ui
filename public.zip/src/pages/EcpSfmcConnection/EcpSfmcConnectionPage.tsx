import React from 'react'
import { useOutletContext } from 'react-router-dom';

const EcpSfmcConnectionPage = () => {
  const [selectedOutlet,setSelectedOutlet] = useOutletContext<any>();
  return (
   <div>
    EcpSfmcConnectionPage
   </div>
  )
}

export default EcpSfmcConnectionPage