import React from 'react'
import { useOutletContext } from 'react-router-dom';

const EcpSfmcEventDefinationPage = () => {
  const [selectedOutlet,setSelectedOutlet] = useOutletContext<any>();
  return (
    <div>EcpSfmcEventDefinationPage</div>
  )
}

export default EcpSfmcEventDefinationPage