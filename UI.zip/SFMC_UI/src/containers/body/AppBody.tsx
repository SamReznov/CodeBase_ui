import React, { useState } from "react";
  import "./AppBody.scss";
  import { Outlet } from "react-router-dom";
  
  
  const AppBody = () => {
    //const user = useSelector((state: any) => state.user.currentUser);
    const [selectedOutlet, setSelectedOutlet] = useState<any>();
  
    return (
      <div>
        <section className="app-body">
          <Outlet context={[selectedOutlet, setSelectedOutlet]} />
        </section>
      </div>
    );
  };
  
  export default AppBody;
  