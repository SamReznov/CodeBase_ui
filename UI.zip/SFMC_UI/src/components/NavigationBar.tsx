import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import './NavigationBar.scss';
const NavigationBar = () => {
  
    const [display, setDisplay] = useState({whichTab:'ECPSFMCPAYLOAD'});
      const handleChange = (e:any) => {
        let updatedValue = {};
        updatedValue = {item1:e};
        console.log(e);
        setDisplay(prevState => ({ ...prevState, whichTab: e }));
         }
      const navigate = useNavigate();
      return (
        <div className='navigationBar'>
        {/* <div className={display.whichTab == "LandingPage" ? "navButton active": "navButton"} onClick={()=>{handleChange('LandingPage');navigate('/')}}>Home (VIEW CONFIG)</div> */}
        <div className={display.whichTab == "EcpSfmcConnection" ? "navButton active": "navButton"} onClick={()=>{handleChange('EcpSfmcConnection');navigate('/sfmcConnection')}}>SFMC CONNECTION</div>
        <div className={display.whichTab == "EcpSfmcDefination" ? "navButton active": "navButton"} onClick={()=>{handleChange('EcpSfmcDefination');navigate('/sfmcEventDefination')}}>SFMC EVENT DEFINATION</div>
        {/* <div className={display.whichTab == "EcpSfmcMappingList" ? "navButton active": "navButton"} onClick={()=>{handleChange('EcpSfmcMappingList');navigate('/sfmcMappingList')}}>SFMC MAPPING LIST</div> */}
        
        </div>
      )
    }

export default NavigationBar