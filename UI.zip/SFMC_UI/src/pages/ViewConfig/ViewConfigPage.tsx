import { useOutletContext } from "react-router-dom";
import "./ViewConfigPage.scss";

const ViewConfigPage = () => {
  const [selectedOutlet, setSelectedOutlet] = useOutletContext<any>();
  return <div>ViewConfigPage</div>;
};

export default ViewConfigPage;
