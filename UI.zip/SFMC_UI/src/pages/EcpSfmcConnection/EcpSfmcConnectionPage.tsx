import React, { useState } from 'react'
import { useOutletContext } from 'react-router-dom';
import { SfmcConnection } from '../models/SfmcConnection';
const EcpSfmcConnectionPage = () => {
  const [selectedOutlet,setSelectedOutlet] = useOutletContext<any>();
    
  const [clientId] = useState('');
    
  function updateConnection(sfmcconnection:Object) {



    console.log(sfmcconnection);
}
function removecConnection(distributer:Object){

}
  return (
    <div className='container'>

    <h2 className='text-center'>SFMC Connection Details</h2>
    <table className='table table-striped table-bordered'>
        <thead>
            <tr>
                <th>Client Id</th>
                <th>Client Secret</th>
                <th>Distributer</th>
                <th>URl</th>
            </tr>
        </thead>
        <tbody>
            {
                SfmcConnection.map(sfmc => 
                    <tr key={sfmc.client_Id}>
                        <td>{sfmc.client_Id}</td>
                        <td>{sfmc.client_Secret}</td>
                        <td>{sfmc.distributer}</td>
                        <td>{sfmc.sfmc_url}</td>
                        <td>
                            <button className='btn btn-info' onClick={() => updateConnection(sfmc)}>Update</button>
                            <button className='btn btn-danger' onClick={() => removecConnection(sfmc)}
                                style={{marginLeft: '10px'}}
                            >Delete</button>
                        </td>
                    </tr>)
            }
        </tbody>
    </table>
    <button className='btn btn-primary mb-2'>Add New Connection</button>
</div>
  
  )
}

export default EcpSfmcConnectionPage