import React from 'react';
export  const SfmcConnection =[{
    client_Id:"123",
    client_Secret:"jhg",
    distributer:"broker",
    sfmc_url:"https://broker.com"
  },
  {
    client_Id:"653",
    client_Secret:"der",
    distributer:"intact",
    sfmc_url:"https://sfmc.com"
  },
  {
    client_Id:"897",
    client_Secret:"uyt",
    distributer:"BLR",
    sfmc_url:"https://my.com"
  }];