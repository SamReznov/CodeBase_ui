import React from 'react'
import { useOutletContext } from 'react-router-dom';

const EcpSfmcMappingListPage = () => {
  const [selectedOutlet,setSelectedOutlet] = useOutletContext<any>();
  return (
    <div>EcpSfmcMappingListPage</div>
  )
}

export default EcpSfmcMappingListPage